from django import forms

from users.models import CustomUser


class UserRegisterForm(forms.ModelForm):
    first_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}))
    last_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}))
    username = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}))
    email = forms.EmailField(widget=forms.TextInput(attrs={'class': 'form-control'}))
    password = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}))



    class Meta:
        model = CustomUser
        fields = ('first_name','last_name','username','email','password','profile_image',)


    def save(self, commit=True):
        hash = super().save(commit)
        hash.set_password(self.cleaned_data['password'])
        hash.save()


class ProfileEditForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ('first_name','last_name','profile_image',)