from django.contrib.auth import login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import render, redirect
from django.views import View

from users.forms import UserRegisterForm, ProfileEditForm


# Create your views here.
class UserRegisterView(View):
    def get(self,request):
        user_form = UserRegisterForm()
        return render(request,'register.html',{"form":user_form})

    def post(self,request):
        user_form = UserRegisterForm(data=request.POST,files=request.FILES)

        if user_form.is_valid():
            user_form.save()
            return redirect("users:login")
        else:
            return render(request, 'register.html', {"form": user_form})


class LoginView(View):
    def get(self,request):
        user_form = AuthenticationForm()
        return render(request,'login.html',{"form":user_form})

    def post(self,request):
        user_form = AuthenticationForm(data=request.POST)

        if user_form.is_valid():
            user = user_form.get_user()
            login(request,user)
            return redirect("main")
        else:
            return render(request, 'login.html', {"form": user_form})


class ProfileView(View):
    def get(self,request):
        user = request.user
        context = {
            "user":user
        }

        return render(request,'profile.html',context)


class LogoutView(View):
    def get(self,request):
        logout(request)
        return redirect("main")


class ProfileEditView(View):
    def get(self,request):
        user= ProfileEditForm(instance=request.user)

        return render(request,'profile-edit.html',{"form":user})

    def post(self,request):
        user= ProfileEditForm(instance=request.user,data=request.POST,files=request.FILES)

        if user.is_valid():
            user.save()
            return redirect("users:profile")
        else:
            return render(request,'profile-edit.html',{"form":user})