from django.db import models

from shared.models import BaseModal


# Create your models here.
class ClassRoomAchivments(models.Model):
    file = models.FileField(upload_to='achivment-class/',blank=True,null=True)




class ClassRoom(models.Model):
    name = models.CharField(max_length=2,unique=True)
    class_img = models.ImageField(upload_to='class-img/')
    achivment = models.ForeignKey(ClassRoomAchivments,on_delete=models.CASCADE,related_name='achivment')
    def __str__(self):
        return self.name


