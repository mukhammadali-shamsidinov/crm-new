from django.apps import AppConfig


class ClassConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'class'
