from django.contrib import admin
from .models import ClassRoom,ClassRoomAchivments
# Register your models here.
admin.site.register(ClassRoom)
admin.site.register(ClassRoomAchivments)