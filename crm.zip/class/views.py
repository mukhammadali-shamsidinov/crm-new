from django.shortcuts import render
from django.views import View
from django.views.generic import ListView

from student.models import Student
from .models import ClassRoom

# Create your views here.
class ClassListView(View):
    def get(self,request):
        classes = ClassRoom.objects.all()

        for x in classes:
            student = Student.objects.filter(Class=x)

            student = student.count()

        print(classes)
        return render(request,'class.html',{"classes":classes,"count":student})


class ClassDteailView(View):
    def get(self,request,pk):
        classes = ClassRoom.objects.get(pk=pk)
        student = Student.objects.filter(Class=classes)
        count = Student.objects.filter(Class=classes).count()
        print(student)
        return render(request,'detail-class.html',{"students":student,"count":count})
