from django.urls import path
from .views import ClassListView,ClassDteailView
app_name="class"
urlpatterns = [
    path('all/',ClassListView.as_view(),name="all"),
    path('detail-class/<int:pk>/',ClassDteailView.as_view(),name="detail"),
]