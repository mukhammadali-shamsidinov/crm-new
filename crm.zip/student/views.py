from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render
from django.views import View
from django.views.generic import DetailView

from student.models import Student, StudentRelative


# Create your views here.
class StudentsView(View,LoginRequiredMixin):
    def get(self,request):
        students = Student.objects.all()

        return render(request,'students.html',{"students":students})


class DetailStudent(View,LoginRequiredMixin):
    def get(self,request,pk):
        model = Student.objects.get(pk=pk)
        print(model.relative.father_fullname)
        return render(request,'detail.html',{"student":model})

class DetailParentView(View):
    def get(self,request,pk):
        model = StudentRelative.objects.get(pk=pk)
        print(model)
        return render(request,'parent.html',{"parent":model})