from django.db import models

from shared.models import BaseModal


# Create your models here.
class Student(models.Model):

    first_name = models.CharField(max_length=128)
    last_name = models.CharField(max_length=128)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=13)
    student_img = models.ImageField(upload_to='student-img/',default='images.png')
    GENDER = (
        ('male','male'),
        ('female','female')
    )
    gender = models.CharField(choices=GENDER,default='male')
    relative = models.ForeignKey('student.StudentRelative',on_delete=models.CASCADE,related_name='relative')
    achivment = models.ForeignKey('student.StudentAchivment',on_delete=models.CASCADE,related_name='achivment')
    Class = models.ForeignKey('class.ClassRoom',on_delete=models.CASCADE,related_name='class_student')
    interest = models.TextField()
    ball = models.IntegerField(default=0)

    def __str__(self):
        return self.first_name


class StudentAchivment(models.Model):
    upload = models.FileField(upload_to='achivment/')

class StudentRelative(models.Model):
    father_fullname = models.CharField(max_length=180)
    father_phone = models.CharField(max_length=13)
    father_email = models.EmailField(unique=True)
    JOBS = (
        ('programmer','programmer'),
        ('mentor','mentor'),
        ('businessman',"businessman"),
        ('other','other')
    )
    father_job = models.CharField(choices=JOBS)
    mother_fullname = models.CharField(max_length=180)
    mother_phone = models.CharField(max_length=13)
    mother_email = models.EmailField(unique=True)
    JOBS = (
        ('programmer','programmer'),
        ('mentor','mentor'),
        ('businessman',"businessman"),
        ('other','other')
    )
    mother_job = models.CharField(choices=JOBS)
    def __str__(self):
        return f"{self.father_fullname} {self.mother_fullname}"