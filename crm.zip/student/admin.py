from django.contrib import admin
from .models import Student,StudentAchivment,StudentRelative
# Register your models here.
admin.site.register(Student)
admin.site.register(StudentAchivment)
admin.site.register(StudentRelative)