from django.urls import path
from .views import StudentsView,DetailStudent,DetailParentView
app_name="students"
urlpatterns = [
    path('all/',StudentsView.as_view(),name="all"),
    path('detail/<int:pk>/',DetailStudent.as_view(),name="detail"),
    path('parent/<int:pk>/',DetailParentView.as_view(),name="detail_parent"),

]