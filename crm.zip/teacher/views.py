from django.shortcuts import render
from django.views.generic import ListView, DetailView

from teacher.models import Teacher


# Create your views here.
class TeacherView(ListView):
    model = Teacher
    template_name = 'teachers.html'
    context_object_name = 'teachers'

class TeacherDetailView(DetailView):
    model = Teacher
    template_name = 'detail.html'
    context_object_name = 'teacher'