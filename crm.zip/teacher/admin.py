from django.contrib import admin
from .models import TeacherRelative,Teacher,TeacherAchivment
# Register your models here.
admin.site.register(Teacher)
admin.site.register(TeacherAchivment)
admin.site.register(TeacherRelative)

