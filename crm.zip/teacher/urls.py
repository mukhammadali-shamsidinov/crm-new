from django.urls import path
from .views import TeacherView,TeacherDetailView
app_name="teachers"
urlpatterns = [
    path('all/',TeacherView.as_view(),name="all"),
    path('teacher/<int:pk>/',TeacherDetailView.as_view(),name="detail")
]