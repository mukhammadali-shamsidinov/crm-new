from django.db import models

from shared.models import BaseModal


# Create your models here.
class Teacher(models.Model):
    first_name =models.CharField(max_length=128)
    last_name = models.CharField(max_length=128)
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=13)
    teacher_img = models.ImageField(upload_to='teacher/')
    SPECIAL = (
        ('Matematika','Matematika'),
        ('Ona tili','Ona tili'),
        ('Enlish tili','English tili'),
        ('Tarix','Tarix'),
        ('Adabiyot','Adabiyot'),
        ('Jismoniy tarbiya','Jismoniy tarbiya'),
        ('Mehnat','Mehnat'),
        ('Informatika','Informatika'),
        ('Geometriya','Geometriya'),
        ('Huquq','Huquq'),
        ('Musiqa','Musiqa')
    )
    special = models.CharField(choices=SPECIAL)
    GENDER = (
        ('male','male'),
        ('female','female')
    )
    gender = models.CharField(choices=GENDER,default='male')
    achivment = models.ForeignKey('teacher.TeacherAchivment',on_delete=models.CASCADE,related_name='achivment')
    relative = models.ForeignKey('teacher.TeacherRelative',on_delete=models.CASCADE,related_name='relative')

    def __str__(self):
        return self.first_name


class TeacherAchivment(models.Model):
    upload = models.FileField(upload_to='achivment/')

class TeacherRelative(models.Model):
    first_name =models.CharField(max_length=128)
    last_name = models.CharField(max_length=128)
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=13)
    GENDER = (
        ('male','male'),
        ('female','female')
    )
    gender = models.CharField(choices=GENDER,default='male')
    RELATIVE=(
        ('uncle','uncle'),
        ('father','father'),
        ('mather','mother')
    )
    relative_choices = models.CharField(choices=RELATIVE)
    interest = models.TextField()

    def __str__(self):
        return self.first_name